/* COE838 - System-on-Chip
 * Lab 4 - Custom IP for HPS/FPGA Systems
 * main.c
 *	
 *  Created on: 2014-11-15
 *  Author: Anita Tino
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <sys/mman.h>
#include "hwlib.h"
#include "socal/socal.h"
#include "socal/hps.h"
#include "socal/alt_gpio.h"
#include "hps_0.h"

#define LW_SIZE 0x00200000
#define LWHPS2FPGA_BASE 0xff200000

volatile uint32_t *md5_group_control = NULL;
volatile uint32_t *md5_group_data = NULL;
int success, total;

void md5_calc_seq(){
	alt_write_word(md5_group_control +1, 0xFFFFFFFF); // reset

	struct timespec start_time, stop_time;
	double elapsed_time;
	char *word = "hello";
	uint32_t correct_hash[4] = {0x5d41402a, 0xbc4b2a76, 0xb9719d91, 0x1017c592};
	uint32_t hashed[4] {0x0,0x0,0x0,0x0}
	uint32_t md5_input[16] = {
	    0x68656C6C, 
	    0x6F000000,
	    0x00000000,
	    0x00000000, 
	    0x00000000, 
	    0x00000000, 
	    0x00000000,
	    0x00000000,
	    0x00000000,
	    0x00000000, 
	    0x00000000, 
	    0x00000000,
	    0x00000000,
	    0x00000000,
	    0x00000000,
	    0x00000000};

    int digest_split =0;
	for (int i =0; i<16;i++){
		alt_write_word(md5_group_control + 2, 0x0);
		alt_write_word(md5_group_data, md5_input[i]); // writedata
		alt_write_word(md5_group_data + 1, 0x0 + i); // writeaddr
		alt_write_word(md5_group_control + 2, 0x1); // wr
	}

	clock_gettime(CLOCK_REALTIME, &start_time);
	double TIME1 = start_time.tv_sec * (1000000000) + start_time.tv_nsec;
	alt_write_word(md5_group_control, 1)// start
	

	while (!(alt_read_word(md5_group_control + 2) &0x1)); // loop till done

	
	alt_write_word(md5_group_control + 2, 0);

	clock_gettime(CLOCK_REALTIME, &stop_time);

	double TIME2 = stop_time.tv_sec * (1000000000) + stop_time.tv_nsec;
   	elapsed_time = TIME2 - TIME1;

	for (int i =0; i<4;i++){
		alt_write_word(md5_group_data +3, 0x0 + i) // get a,b,c,d digest adress
		hashed[i] = alt_read_word(md5_group_data + 3) // get the values
	}

	printf(" Digest for '%s' is %08x%08x%08x%08x\nCalculation Time: %0.8f", word, hashed[0], hashed[1], hashed[2], hashed[3], elapsed_time);


	if (correct_hash[0] == hashed[0] && correct_hash[1] == hashed[1] && correct_hash[2] == hashed[2] && correct_hash[3] == hashed[3]){
		printf("\nThis matches the correct hash value for: %s\n", word);
	}
	else{
		printf("\nThis does not match the correct hash value for: %s\n", word);
	}


}



void md5_calc_par(){
	alt_write_word(md5_group_control +1, 0xFFFFFFFF); // reset


	struct timespec start_time, stop_time;
	double elapsed_time;
	char *word = "hello";
	char *word = "COE838";
	uint32_t correct_hash[4] = {0x5d41402a, 0xbc4b2a76, 0xb9719d91, 0x1017c592}; 
	uint32_t correct_hash2[4] = {0x4a3b0370, 0xf636cc43, 0x67279f6d, 0xaf0d62ba}; 
	uint32_t hashed[4] {0x0,0x0,0x0,0x0}
	uint32_t md5_input1[16] = {
	    0x65686C6C, 
	    0x6F000000,
	    0x00000000,
	    0x00000000, 
	    0x00000000, 
	    0x00000000, 
	    0x00000000,
	    0x00000000,
	    0x00000000,
	    0x00000000, 
	    0x00000000, 
	    0x00000000,
	    0x00000000,
	    0x00000000,
	    0x00000000,
	    0x00000000};

	uint32_t md5_input2[16] = {
	    0x434F4538, 
	    0x33380000,
	    0x00000000,
	    0x00000000, 
	    0x00000000, 
	    0x00000000, 
	    0x00000000,
	    0x00000000,
	    0x00000000,
	    0x00000000, 
	    0x00000000, 
	    0x00000000,
	    0x00000000,
	    0x00000000,
	    0x00000000,
	    0x00000000};

	uint32_t addr_data = 0x0;
	for (int core = 0; core < 2; core++){
		for (int i =0; i< 16;i++){
			for (int j =0; j< 16;j++){
				addr_data = 0x0;
				alt_write_word(md5_group_control + 2, 0x0);
				if (core == 0) alt_write_word(md5_group_data, md5_input[j]); // writedata
				if (core == 1) alt_write_word(md5_group_data, md5_input2[j]);
				addr_data = ((addr_data + i) << 1) + core;
				alt_write_word(md5_group_data + 1, (addr_data << 4) + j); // writeaddr
				alt_write_word(md5_group_control + 2, 0x1);
			}
		}
	}

	clock_gettime(CLOCK_REALTIME, &start_time);
	double TIME1 = start_time.tv_sec * (1000000000) + start_time.tv_nsec;
	alt_write_word(md5_group_control, 0xFFFFFFFF);// start

	while (alt_read_word(md5_group_control + 1) != 0xFFFFFFFF); // loop till done

	
	alt_write_word(md5_group_control + 2, 0);

	clock_gettime(CLOCK_REALTIME, &stop_time);

	double TIME2 = stop_time.tv_sec * (1000000000) + stop_time.tv_nsec;
   	elapsed_time = TIME2 - TIME1;

	uint32_t hashed[32][4]; 
	uint32_t read_data = 0x0;
	for (int i =0; i< 32;i++){
		for (int j = 0 ; j < 4 ; j++){
			read_data = (read_data + i) << 2;
			read_data += j;
			alt_write_word( md5_group_data + 2,read_data);
			hashed[i][j] = alt_read_word(md5_group_data +3);
			read_data = 0x0;
		}
	}


	printf(" Digest for '%s' is %08x%08x%08x%08x\n", word, hashed[0][0], hashed[0][1], hashed[0][2], hashed[0][3]);
	printf(" Digest for '%s' is %08x%08x%08x%08x\nnCalculation Time: %0.8f", word2, hashed[1][0], hashed[1][1], hashed[1][2], hashed[1][3], elapsed_time);

	if (correct_hash[0] == hashed[0][0] && correct_hash[1] == hashed[0][1] && correct_hash[2] == hashed[0][2] && correct_hash[3] == hashed[0][3]){
		printf("\nThis matches the correct hash value for: %s\n", word);
	}
	else{
		printf("\nThis does not match the correct hash value for: %s\n", word);
	}

	if (correct_hash2[0] == hashed[1][0] && correct_hash2[1] == hashed[1][1] && correct_hash2[2] == hashed[1][2] && correct_hash2[3] == hashed[1][3]){
		printf("\nThis matches the correct hash value for: %s\n", word2);
	}
	else{
		printf("\nThis does not match the correct hash value for: %s\n", word);
	}


}

	/*
	 *
	 * 	wr							: IN STD_LOGIC;
	 * 	writedata					: IN STD_LOGIC_VECTOR(31 DOWNTO 0);
	 * 	writeaddr					: IN STD_LOGIC_VECTOR(8 DOWNTO 0);
	 * 		- to md5_unit: writeaddr(4 DOWNTO 0);
	 * 		- to decode: writeaddr(8 DOWNTO 5);
	 * 	readaddr					: IN STD_LOGIC_VECTOR(6 DOWNTO 0);
	 *		- digest_sel <= readaddr(6 DOWNTO 2);
	 *		- word_sel <= readaddr(1 DOWNTO 0);
	 */



int main(int argc, char **argv){
	int fd, i;
	void *virtual_base; 
	success = 0; total = 0;
	
	//map address space of fpga for software to access here
	if((fd = open("/dev/mem", ( O_RDWR | O_SYNC ) ) ) == -1 ) {
		printf( "ERROR: could not open \"/dev/mem\"...\n" );
		return( 1 );
	}

	virtual_base =  mmap( NULL, LW_SIZE, ( PROT_READ | PROT_WRITE ), MAP_SHARED, fd, LWHPS2FPGA_BASE);

	if( virtual_base == MAP_FAILED ) {
		printf( "ERROR: mmap() failed...\n" );
		close( fd );
		return(1);
	}

	//initialize the addresses
	md5_group_data = virtual_base + ((uint32_t)(MD5_GROUP_DATA_0_BASE) );
	md5_group_control = virtual_base + ((uint32_t)( MD5_GROUP_CONTROL_0_BASE) );

	md5_calc_seq();

	//md5_calc_par();
	

	// clean up our memory mapping and exit
	if( munmap( virtual_base, LW_SIZE) != 0 ) {
		printf( "ERROR: munmap() failed...\n" );
		close( fd );
		return( 1 );
	}

	close( fd );

	
	return 0;

}
